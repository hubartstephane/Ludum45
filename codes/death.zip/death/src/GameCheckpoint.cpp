#include <death/GameCheckpoint.h>

namespace death
{

	// =================================================
	// GameCheckpoint
	// =================================================



}; // namespace death
