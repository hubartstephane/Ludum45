#pragma once

#include <chaos/StandardHeaders.h>
#include <chaos/GPUClasses.h>


namespace chaos
{

	class GPUSkinnedMesh
	{



	};


}; // namespace chaos
