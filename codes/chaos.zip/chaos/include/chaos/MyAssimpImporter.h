#pragma once

#include <chaos/StandardHeaders.h>

namespace chaos
{

	/**
	* MyAssimpImporter : a base class to import ASSIMP file
	*/

	class MyAssimpImporter
	{
	public:

	};

}; // namespace chaos
