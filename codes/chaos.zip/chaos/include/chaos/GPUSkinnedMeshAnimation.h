#pragma once

#include <chaos/StandardHeaders.h>
#include <chaos/GPUClasses.h>

namespace chaos
{

	class GPUSkinnedMeshAnimation
	{



	};

}; // namespace chaos

