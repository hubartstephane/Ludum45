#include <chaos/GPUSkinnedMesh.h>

namespace chaos
{
}; // namespace chaos
