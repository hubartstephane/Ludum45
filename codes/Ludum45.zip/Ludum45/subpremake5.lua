-- =============================================================================
-- ROOT_PATH/executables/LUDUM/Ludum45
-- =============================================================================

  WindowedApp()
  DependOnLib("CHAOS")
  DependOnLib("DEATH")
  DeclareResource("resources")    
