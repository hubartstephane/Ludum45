#include "Ludum45StateMachine.h"
#include "Ludum45Game.h"

LudumStateMachine::LudumStateMachine(class LudumGame * in_game) : 
	death::GameStateMachine(in_game)
{
}