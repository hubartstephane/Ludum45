#pragma once

#include <death/GameCheckpoint.h>

#include <death/TiledMapLevel.h>



class LudumPlayerCheckpoint : public death::PlayerCheckpoint
{
public:


};

class LudumLevelCheckpoint : public death::TiledMap::TiledLevelCheckpoint
{
public:


};